import React from "react";
import logoImage from "figma:asset/7bbd42e1f58e77fab4d35751c2cad3b374d81434.png";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <img
      src={logoImage}
      alt="Harald Logo"
      className={className}
    />
  );
}